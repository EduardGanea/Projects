public class Producer implements Runnable {
    PcQueue P;
    Producer (PcQueue P){
        this.P = P;
        new Thread(this, "Producer").start();  // constructor for the producer class
    }
    public void run(){
        for(int i =0; i < 11; i++)
            P.put(i);               // the incrementing operation
    }
}
