import java.util.concurrent.Semaphore;

public class PcQueue {
    int item;

    static Semaphore semCon = new Semaphore(0);
    static Semaphore semProd = new Semaphore(1);

    void get()
    {
        try {
            semCon.acquire();       // getting the permit to make its operation
        }
        catch (InterruptedException e) {
            System.out.println("InterruptedException caught");
        }

        System.out.println("Consumer consumed item : " + item);         // the implementation of consumer`s operation

        semProd.release();      // notifying the producer that is its turn to do the operation
    }

    void put(int item)
    {
        try {
            semProd.acquire();      // getting the permit to make its operation
        }
        catch (InterruptedException e) {
            System.out.println("InterruptedException caught");
        }

        this.item = item;
                                                                // the implementation of producer`s operation
        System.out.println("Producer produced item : " + item);

        semCon.release();       // notifying the consumer that is its turn to do the operation
    }
}
