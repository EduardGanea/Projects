public class Consumer implements Runnable {
    PcQueue C;
    Consumer (PcQueue C){
        this.C = C;
        new Thread(this, "Consumer").start();       // constructor for the consumer class
    }
    public void run(){
        for(int i =0; i < 11; i++)
            C.get();                // the operation of printing the value
    }
}
