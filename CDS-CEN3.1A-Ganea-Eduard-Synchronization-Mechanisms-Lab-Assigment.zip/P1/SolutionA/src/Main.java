public class Main {
    public static void main(String args[])
    {

        PcQueue q = new PcQueue();      // creating an instance of PcQueue

        new Consumer(q);        // starting consumer thread

        new Producer(q);        // starting producer thread
    }
}
