public class Main {
    public static void main(String[] args) {
        String[] names = {"Plato", "Aristotle", "Cicero", "Confucius", "Eratosthenes"};
        Fork[] fork = new Fork[5];
        Philosopher[] philosopher = new Philosopher[5];     //creating the forks and philosophers

        for (int i = 0; i < fork.length; i++) {
            fork[i] = new Fork(i);          // initializing the positions of forks
        }

        for (int i = 0; i < philosopher.length; i++) {

            if (i != philosopher.length - 1) {
                philosopher[i] = new Philosopher(fork[i], fork[i+1], names[i]);
                philosopher[i].start();     // philosophers eating in a cycle
            } else {
                philosopher[i] = new Philosopher(fork[0], fork[i], names[i]);
                philosopher[i].start();         // last philosopher eating
            }
        }
    }
}
