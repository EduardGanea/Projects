import java.util.concurrent.Semaphore;

public class Fork {
    public Semaphore fork = new Semaphore(1);
    public int id;

    Fork(int id) {
        this.id = id;   // constructor for the forks
    }

    public boolean take() {
        return fork.tryAcquire();       // operation of philosopher getting a fork to eat
    }

    public void putDown() {
        fork.release();                 // operation of philosopher putting down the fork to go back to thinking
    }
}
