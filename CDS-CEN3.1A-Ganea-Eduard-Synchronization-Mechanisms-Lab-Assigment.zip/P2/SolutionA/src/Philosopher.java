public class Philosopher extends Thread {
    private Fork fork_low;
    private Fork fork_high;
    private String name;

    Philosopher(Fork fork_low, Fork fork_high, String name) {       // constructor for a philosopher
        this.fork_low = fork_low;
        this.fork_high = fork_high;
        this.name = name;
    }

    public void run() {
        int i =0;       // iterator for number of items we want the philosophers to eat. Ex: if we choose 5 all the philosophers will eat
        try {
            sleep(1000);
        } catch (InterruptedException ex) {
        }

        while (i < 5) {
            eat();      // the action of eating
            i++;
        }
    }

    private void eat(){
        if(fork_low.take()){        // taking the forks eating
            if(fork_high.take()){
                try {
                    sleep(2000); // eating;
                } catch (InterruptedException ex) { }
                fork_high.putDown();        // putting them down
                fork_low.putDown();
                System.out.println("Philosopher is thinking");

            }
            else{
                fork_low.putDown(); // if you don`t take the high fork, there is no point in having the low one in your hand
            }
        }
    }
}
