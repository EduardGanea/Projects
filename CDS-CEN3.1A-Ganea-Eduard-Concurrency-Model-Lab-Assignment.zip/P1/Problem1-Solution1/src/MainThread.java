import java.util.Scanner;
import java.util.Vector;

public class MainThread {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("Number of threads: ");
        int k = scan.nextInt();  // Create number of threads

        final Prime[] pThreads = new Prime[k];

        long startTime = System.currentTimeMillis(); // the starting time of the compiler

        Prime.primeVector = new Vector<Integer>(1000); // Guaranteed to be enough
        System.out.println("Length of the interval is:");
        int n = scan.nextInt();   // the length of the interval
        int q = n / k + 1;
        for (int i = 0; i < k; i++) {         // making every interval for the specific thread and then putting in the vector only the prime numbers
            pThreads[i] = new Prime(i * q, Math.min(n, (i + 1) * q - 1));
            pThreads[i].start();
        }
        try {
            for (int i = 0; i < k; i++)
                pThreads[i].join();
        } catch (InterruptedException e) {
        }
        long stopTime = System.currentTimeMillis();  // the time the compiler stopped

        long elapsedTime = stopTime - startTime;   // the compiling time
        System.out.println("Execution time = : " + elapsedTime);


        for (int i = 0; i < k; i++)
            System.out.println("Thread " + i + "  Prime count: " + pThreads[i].count); // Display Thread count
        System.out.println("Total prime count: " + Prime.primeVector.size()); // Output total amount of primes from the Array List
        for (int i = 0; i < 100; i++) // Display first 100 primes
            System.out.println(Prime.primeVector);
    }
}
