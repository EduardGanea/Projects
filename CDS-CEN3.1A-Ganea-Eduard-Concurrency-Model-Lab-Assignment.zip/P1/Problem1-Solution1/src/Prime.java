import java.util.Vector;



public class Prime extends Thread {

    public int count = 0;  // a counter for our prime numbers

    static Vector<Integer> primeVector;

    int start, end;  // the starting and the end of an interval

    public Prime(int start, int end) {  // a constructor for our splitted intervals
        this.start = start;
        this.end = end;
    }




    public void run() {                         // checking if a number is prime or not, then if it is increasing the number of
                                                // counted prime numbers and adding the number to the vector
        for (int n = start; n <= end; n++) {
            boolean prime = true;
            if(n >= 2) {
                for (int j = 2; j < n; j++) {
                    if (n % j == 0) {
                        prime = false;
                        break;
                    }
                }

                if (prime) {
                    count++;
                    primeVector.add(n);

                }
            }
        }
    }
}
