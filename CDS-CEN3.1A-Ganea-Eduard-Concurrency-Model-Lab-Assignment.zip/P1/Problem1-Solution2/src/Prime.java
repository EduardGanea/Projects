import java.util.Vector;


public class Prime extends Thread {

    public int count = 0;

    static Vector<Integer> primeVector;

    int start, end;
    public Prime(int start, int end) {
        this.start = start;
        this.end = end;
}




    public void run() {
        for (int n = start; n <= end; n++) {
            boolean prime = true;
            if(n >= 2) {
                for (int j = 2; j < n; j++) {
                    if (n % j == 0) {
                        prime = false;
                        break;
                    }
                }

                if (prime) {
                    count++;
                    primeVector.add(n);

                }
            }
        }

    }
}