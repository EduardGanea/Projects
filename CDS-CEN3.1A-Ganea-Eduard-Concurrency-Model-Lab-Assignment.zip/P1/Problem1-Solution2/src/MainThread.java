import java.util.Scanner;
import java.util.Vector;
public class MainThread {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("How Many threads? ");
        int k = scan.nextInt();  // Create variable 'k'  to handle whatever integer the user specifies.  nextInt() is used for the scanner to expect and Int.

        final Prime[] pThreads = new Prime[k];

        long startTime = System.currentTimeMillis();
        Prime.primeVector = new Vector<Integer>(10000); // Guaranteed to be enough
        System.out.println("Length of the interval is:");
        int n = scan.nextInt();
        int i = 0;
        int q = n / k + 1;
        for (i = 1; i <= n; i++)
            Prime.primeVector.add(i);
        for (int t = 0; t < Prime.primeVector.size(); t++) {
            int x = 2;
            while (x < Prime.primeVector.size()) {
                if (Prime.primeVector.get(t) == x * (k + 1)) {
                    Prime.primeVector.remove(Prime.primeVector.get(t));
                }
                x++;
            }
        }
        for (i = 0; i < k; i++) {
            pThreads[i] = new Prime(i * q, Math.min(n, (i + 1) * q - 1));
            pThreads[i].start();
        }
        try {
            for (i = 0; i < k; i++)
                pThreads[i].join();
        } catch (InterruptedException e) {
        }
        long stopTime = System.currentTimeMillis();

        long elapsedTime = stopTime - startTime;
        System.out.println("Execution time = : " + elapsedTime);

        System.out.println("----------------------------------------------------");

        int cores = Runtime.getRuntime().availableProcessors();
        System.out.println("How many Cores this Java Program used: " + cores);


        for (i = 0; i < k; i++)
            System.out.println("Thread " + i + "  Prime count: " + pThreads[i].count); // Display Thread count
        System.out.println("Total prime count: " + Prime.primeVector.size()); // Output total amount of primes from the Array List
        for (i = 0; i < 100; i++) // Display first 100 primes.
            System.out.println(Prime.primeVector);

        }
    }


