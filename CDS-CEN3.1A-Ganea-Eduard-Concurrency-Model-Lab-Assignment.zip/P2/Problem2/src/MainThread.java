import java.util.concurrent.locks.ReentrantLock;

public class MainThread implements Runnable {
    static int n = 0; // our counter
    static int temp =0; // the variable temp
    static ReentrantLock counterLock = new ReentrantLock(true); // enables us to switch from one thread to the other

    static void incrementCounter(){    // the function for the incremantation of the counter using the counterlock to switch
                                       // between threads

                counterLock.lock();


                try {
                    System.out.println(Thread.currentThread().getName() + ": " + n);
                    temp = n;
                    n = temp + 1;
                } finally {
                    counterLock.unlock();
                }
        }

    public void run() {         // the run of our class which we use to repeat the incrementing as many times as we want
        while(n < 20) {
            incrementCounter();
        }
    }

    public static void main(String[] args) {  // the main function helps us generate and then start the threads
        MainThread te = new MainThread();
        Thread thread1 = new Thread(te);
        Thread thread2 = new Thread(te);
        thread1.start();
        thread2.start();
    }
}