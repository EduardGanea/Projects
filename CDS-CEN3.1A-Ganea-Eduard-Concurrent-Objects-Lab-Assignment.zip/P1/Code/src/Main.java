import java.io.IOException;
import java.nio.channels.Channel;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {
    public static class Fork {
        Channel up = new Channel() {        // channel declaration and his specific operations
            @Override
            public boolean isOpen() {
                return true;
            }

            @Override
            public void close() throws IOException {

            }
        };  // the lock for making sure only one philosopher can use a fork at a time
        private final int id;

        public Fork(int id) {   // constructor for the fork
            this.id = id;
        }

        public boolean pickUp(Philosopher who, String where) throws InterruptedException {  // the action of picking up a fork
            if (up.isOpen()) {
                System.out.println(who + " picked up " + where + " " + this);
                return true;
            }
            return false;
        }

        public void putDown(Philosopher who, String name) {     // the action of putting down the fork
            try {
                up.close();
            } catch (IOException e){
                e.printStackTrace();
            }
            System.out.println(who + " put down " + name + " " + this);
        }

        public String toString() {
            return "Fork-" + id;
        }
    }


    public static class Philosopher implements Runnable {
        private final int id;

        private final Fork leftFork;
        private final Fork rightFork;

        volatile boolean isTummyFull = false;   // true if a philosopher eats

        private Random randomGenerator = new Random();

        private int noOfTurnsToEat = 0;     // how many times a philosopher ate


        public Philosopher(int id, Fork leftFork, Fork rightFork) {     // constructor for the philosopher
            this.id = id;
            this.leftFork = leftFork;
            this.rightFork = rightFork;
        }

        public void run() {

            try {
                while (!isTummyFull) {

                    think();    // thinking action

                    if (leftFork.pickUp(this, "left")) {        // picking the forks and eating then puting them down
                        if (rightFork.pickUp(this, "right")) {
                            eat();
                            rightFork.putDown(this, "right");
                        }
                        leftFork.putDown(this, "left");
                    }
                }
            } catch (Exception e) {
                // Catch the exception outside the loop.
                e.printStackTrace();
            }
        }

        private void think() throws InterruptedException {      // thinking action
            System.out.println(this + " is thinking");
            Thread.sleep(randomGenerator.nextInt(1000));
        }

        private void eat() throws InterruptedException {        // eating action
            System.out.println(this + " is eating");
            noOfTurnsToEat++;
            Thread.sleep(randomGenerator.nextInt(1000));
        }


        public int getNoOfTurnsToEat() {    // calculating number of turn a philsopher ate

            return noOfTurnsToEat;
        }

        public String toString() {
            return "Philosopher-" + id;
        }
    }

    private static final int NO_OF_PHILOSOPHER = 5; // number of philosophers used
    private static final int SIMULATION_MILLIS = 100 * 10;      // the time we want the program to run

    public static void main(String args[]) throws InterruptedException {
        ExecutorService executorService = null;

        Philosopher[] philosophers = null;
        try {

            philosophers = new Philosopher[NO_OF_PHILOSOPHER];

            Fork[] Forks = new Fork[NO_OF_PHILOSOPHER];

            for (int i = 0; i < NO_OF_PHILOSOPHER; i++) {
                Forks[i] = new Fork(i);
            }

            executorService = Executors.newFixedThreadPool(NO_OF_PHILOSOPHER);

            for (int i = 0; i < NO_OF_PHILOSOPHER; i++) {
                philosophers[i] = new Philosopher(i, Forks[i], Forks[(i + 1) % NO_OF_PHILOSOPHER]);
                executorService.execute(philosophers[i]);
            }
            // Main thread sleeps till time of simulation
            Thread.sleep(SIMULATION_MILLIS);
            // Stop all philosophers.
            for (Philosopher philosopher : philosophers) {
                philosopher.isTummyFull = true;
            }

        } finally {
            // Close everything down.
            executorService.shutdown();

            // Wait for all thread to finish
            while (!executorService.isTerminated()) {
                Thread.sleep(1000);
            }

            // Time for check
            for (Philosopher philosopher : philosophers) {
                System.out.println(philosopher + " => No of Turns to Eat ="
                        + philosopher.getNoOfTurnsToEat());
            }
        }
    }
}
