import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class LockBasedQueue<T>
{
    /**
     * This variable represents the
     * head of the queue
     */
    volatile int _head;
    /**
     * This variable represents the
     * end of the queue
     */
    volatile int _tail;

    /**
     * the items that are stored
     */
    T[] _itemsArray;
    /**
     * the reentrant lock
     */
    Lock _lock;
    /**
     * conditions that take care of
     * the corner cases (empty or full)
     */
    Condition condEmpty;
    Condition condFull;

    /**
     * constructor
     * @param arraySize size of the queue
     */
    public LockBasedQueue(int arraySize)
    {
        _head = 0;
        _tail = 0;
        _lock = new ReentrantLock();
        condEmpty = _lock.newCondition();
        condFull = _lock.newCondition();
        _itemsArray = (T[]) new Object[arraySize];
    }


    /**
     * this method returns and removes
     * the first element of the queue
     * First it tries to acquire the lock
     * then checks if the queue is empty
     * then takes the element
     * @return the first element of the queue
     */
    public T deq()
    {
        _lock.lock();
        try
        {
            while(_tail == _head)
            {
                try {
                    condEmpty.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            T x = _itemsArray[_head % _itemsArray.length];
            _head++;
            condFull.signalAll();
            return x;
        } finally {
            _lock.unlock();
        }
    }

    /**
     * this method adds an element
     * at the end of the queue
     * First it tries to acquire the lock
     * then it checks if the queue is full
     * and then, adds x to the queue
     * @param x value to add
     */
    public void enq(T x)
    {
        _lock.lock();
        try {
            while (_tail - _head == _itemsArray.length)
            {
                try {
                    condFull.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            _itemsArray[_tail % _itemsArray.length] = x;
            _tail++;
        } finally {
            condEmpty.signalAll();
            _lock.unlock();
        }
    }
}
