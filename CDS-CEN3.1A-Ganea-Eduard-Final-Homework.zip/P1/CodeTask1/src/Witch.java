import java.util.concurrent.Semaphore;

public class Witch extends Thread
{
    /**
     * the id of the witch
     */
    int WitchId;
    /**
     * The coven that the witch visits
     */
    Coven cvn;
    /**
     * Channel between coven and witch
     */
    LockBasedQueue<Ingredient> CovenWitch;
    /**
     * Channel between Witch and Grand Sorcerer
     */
    LockBasedQueue<Ingredient> WitchGrandSorcerer;

    /**
     * Semaphore for witch and coven
     */
    Semaphore WitchSem;

    /**
     * Constructor
     * @param WitchId
     * @param cvn
     * @param CovenWitch
     * @param WitchGrandSorcerer
     * @param WitchSem
     */
    public Witch(int WitchId, Coven cvn, LockBasedQueue<Ingredient> CovenWitch,
                 LockBasedQueue<Ingredient> WitchGrandSorcerer, Semaphore WitchSem) {
        super();
        this.WitchId = WitchId;
        this.cvn = cvn;
        this.CovenWitch = CovenWitch;
        this.WitchGrandSorcerer = WitchGrandSorcerer;
        this.WitchSem = WitchSem;
    }

    /**
     * Method that simulates the visit of the Witch
     * from the problem statement
     */
    public void run()
    {
        WitchSem.tryAcquire();
        Ingredient WitchPotion = CovenWitch.deq();
        WitchSem.release();
        System.out.println("Am creat o potiune");
        preparePotion(WitchPotion);
        WitchGrandSorcerer.enq(WitchPotion);
    }

    /**
     * Method that creates the potion.
     * @param reindeerGift
     */
    public void preparePotion(Ingredient WitchPotion)
    {
        WitchPotion.setPickedup(true);
        RandomNum rand = new RandomNum();
        try
        {
            Thread.sleep(rand.randomNumber(11,30));
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }

    }

    /**
     * getter for the witch id
     * @return witch id
     */
    public int getWitchId()
    {
        return WitchId;
    }
    /**
     * setter for the witch id
     * @param WitchId
     */
    public void setWitchId(int WitchId)
    {
        this.WitchId = WitchId;
    }
    /**
     * getter for coven
     * @return the coven
     */
    public Coven getCvn()
    {
        return cvn;
    }

    /**
     * setter for coven
     * @param cvn
     */
    public void setCvn(Coven cvn)
    {
        this.cvn = cvn;
    }
    /**
     * getter for the channel between coven and witch
     * @return channel between coven and witch
     */
    public LockBasedQueue<Ingredient> getCovenWitch()
    {
        return CovenWitch;
    }
    /**
     * setter for the channel between coven and witch
     * @param factoryReindeer
     */
    public void setCovenWitch(LockBasedQueue<Ingredient> CovenWitch)
    {
        this.CovenWitch = CovenWitch;
    }
    /**
     * getter for the channel between witch and Grand Sorcerer
     * @return channel between witch and Grand Sorcerer
     */
    public LockBasedQueue<Ingredient> getWitchGrandSorcerer()
    {
        return WitchGrandSorcerer;
    }
    /**
     * setter for the channel between witch and Grand Sorcerer
     * @param WitchGrandSorcerer
     */
    public void setWitchGrandSorcerer(LockBasedQueue<Ingredient> WitchGrandSorcerer)
    {
        this.WitchGrandSorcerer = WitchGrandSorcerer;
    }

}
