public class Main {

    public static void main(String args[])
    {
        GrandSorcererCircle Circle = new GrandSorcererCircle();
        Circle.start();

    }
}
