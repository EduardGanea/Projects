import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class Demon extends Thread{

    /**
     * the index of the demon
     */
    int DemonId;
    /**
     * type of ingredient the demon has to produce
     */
    int numberOfIngredient;
    /**
     * the social skill of a demon
     */
    int social;
    /**
     * the position in the grid
     */
    Position poz;
    /**
     * the coven
     */
    Coven cvn;

    /**
     * barrier for demons
     */
    CyclicBarrier DemonsBarrier;
    /**
     * constructor
     * @param DemonId
     * @param numberOfIngredient
     * @param poz
     * @param cvn
     * @param DemonsBarrier
     */
    public Demon(int DemonId, int numberOfIngredient, int social, Position poz, Coven cvn, CyclicBarrier DemonsBarrier)
    {
        this.DemonId = DemonId;
        this.numberOfIngredient = numberOfIngredient;
        this.social = social;
        this.poz = poz;
        this.cvn = cvn;
        this.DemonsBarrier = DemonsBarrier;
    }

    /**
     * Method that simulates the behavior of the demon described
     * in the problem statement. The demon tries to go to a new position,
     * by choosing a random neighbor. If the random neighbor is available,
     * it goes there and generates an ingredient that is given to the coven.
     */
    public void run()
    {
        RandomNum rand = new RandomNum();
        boolean runnable = true;
        int finished = 0;
        LockBasedQueue<Ingredient> Q = cvn.getCovenWitch();
        int count =0;
        while(runnable)
        {
            Position auxPoz = nextPosition(poz);
            while(auxPoz.getColumnId() == poz.getColumnId() &&
                    auxPoz.getRowId() == poz.getRowId())        // the demon can't move
            {
                count++;
                try
                {
                    Thread.sleep(rand.randomNumber(11,50)); // the demon sleeps and waits for a new position
                }
                catch (InterruptedException e)
                {
                    e.printStackTrace();
                }

                auxPoz = nextPosition(poz);
            }
            if(count > 10){
                social = social -100;
                count =0;
            }
            poz = auxPoz;


            finished ++;

            Q.enq(new Ingredient(numberOfIngredient, poz, true));
            if(social >= 100 && social < 200){
                Q.enq(new Ingredient(numberOfIngredient, poz, true));
            }
            if(social >= 200 && social < 300){
                for(int i =0 ; i < 2; i++) {
                    Q.enq(new Ingredient(numberOfIngredient, poz, true));
                }
            }
            if(social >= 300 && social < 400){
                for(int i =0 ; i < 3; i++) {
                    Q.enq(new Ingredient(numberOfIngredient, poz, true));
                }
            }
            if(social >= 400 && social < 500){
                for(int i =0 ; i < 4; i++) {
                    Q.enq(new Ingredient(numberOfIngredient, poz, true));
                }
            }
            if(social >= 500 && social < 600){
                for(int i =0 ; i < 5; i++) {
                    Q.enq(new Ingredient(numberOfIngredient, poz, true));
                }
            }
            if(social >= 600 && social < 700){
                for(int i =0 ; i < 6; i++) {
                    Q.enq(new Ingredient(numberOfIngredient, poz, true));
                }
            }
            if(social >= 700 && social < 800){
                for(int i =0 ; i < 7; i++) {
                    Q.enq(new Ingredient(numberOfIngredient, poz, true));
                }
            }
            if(social >= 800 && social < 900){
                for(int i =0 ; i < 8; i++) {
                    Q.enq(new Ingredient(numberOfIngredient, poz, true));
                }
            }
            if(social >= 900 && social < 1000){
                for(int i =0 ; i < 9; i++) {
                    Q.enq(new Ingredient(numberOfIngredient, poz, true));
                }
            }
            if(social >= 1000){
                for(int i =0 ; i < 10; i++) {
                    Q.enq(new Ingredient(numberOfIngredient, poz, true));
                }
            }
            System.out.println("Demon " + DemonId + " created Ingredient" + finished);

            if(numberOfIngredient == finished)
            {
                runnable = false;
            }
        }
    }

    /**
     * Method that returns the next position in which the demon should move.
     * If the same position is return, it means that the demon cannot move and
     * he sleeps in the run thread.
     * @param currentPosition
     * @return the next position
     */
    synchronized Position nextPosition(Position currentPosition)
    {
        Position nextPos = new Position(currentPosition.getRowId(), currentPosition.getColumnId());
        int dx[] = {-1, 0, 1, 0};
        int dy[] = {0, -1, 0, 1};
        CovenGrid cvnGrid = cvn.getGrid();
        boolean[][] grid = cvnGrid.getGrid();
        ArrayList<Integer> rnd = new ArrayList<Integer>();

        for(int i = 0; i < 4; i ++)
        {
            rnd.add(i);
        }
        Collections.shuffle(rnd);

        for(int i = 0; i < 4; i ++)
        {
            if(grid[nextPos.getRowId() + dx[rnd.get(i)]][nextPos.getColumnId() + dy[rnd.get(i)]] == false)
            {
                nextPos.setRowId(nextPos.getRowId() + dx[rnd.get(i)]);
                nextPos.setColumnId(nextPos.getColumnId() + dy[rnd.get(i)]);
                grid[nextPos.getRowId()][nextPos.getColumnId()] = true;
                return nextPos;
            }
        }

        return currentPosition;
    }

    /**
     * Notify the coven that the demon was created.
     */
    public void notifyCoven()
    {
        try{
            sleep(10);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
        CovenGrid cvnGrid = cvn.getGrid();
        boolean[][] grid = cvnGrid.getGrid();

        grid[this.poz.getRowId()][this.poz.getColumnId()] = true;
    }

    /**
     * getter for demon index
     * @return demon index
     */
    public int getDemonId()
    {
        return DemonId;
    }

    /**
     * setter for demon index
     * @param DemonId
     */
    public void setDemonId(int DemonId)
    {
        this.DemonId = DemonId;
    }

    /**
     * getter for the type of ingredient the demon has to produce
     * @return type of ingredient
     */
    public int getNumberOfIngredient()
    {
        return numberOfIngredient;
    }

    /**
     * setter for the type of ingredient the demon has to produce
     * @param numberOfIngredient
     */
    public void setNumberOfIngredient(int numberOfIngredient)
    {
        this.numberOfIngredient = numberOfIngredient;
    }

    /**
     * getter for the position in the grid
     * @return position in the grid
     */
    public Position getPoz()
    {
        return poz;
    }

    /**
     * setter for the position in the grid
     * @param poz
     */
    public void setPoz(Position poz)
    {
        this.poz = poz;
    }

    /**
     * getter for the coven in which the demon is
     * working
     * @return coven
     */
    public Coven getCvn()
    {
        return cvn;
    }

    /**
     * setter for the coven in which the demon is
     * working
     * @param cvn
     */
    public void setCvn(Coven cvn)
    {
        this.cvn = cvn;
    }

}
