public class Ingredient {

    /**
     * The index of the ingredient
     */
    int index;

    /**
     * The location of the ingredient in the grid
     */
    Position location;
    /**
     * was picked up by a witch or not
     */
    boolean isFinished;

    /**
     * Constructor
     * @param index
     * @param location
     * @param isFinished
     */
    public Ingredient(int index, Position location, boolean isFinished)
    {
        this.index = index;
        this.location = location;
        this.isFinished = isFinished;
    }

    /**
     * getter for index
     * @return the index of the ingredient
     */
    public int get_index()
    {
        return index;
    }
    /**
     * setter for index
     * @param index
     */
    public void set_index(int index)
    {
        this.index = index;
    }
    /**
     * getter for location
     * @return the location in the grid
     */
    public Position getLocation()
    {
        return location;
    }
    /**
     * setter for location in grid
     * @param location
     */
    public void setLocation(Position location)
    {
        this.location = location;
    }
    /**
     * getter to find if it was picked up
     * @return
     */
    public boolean isPickedup()
    {
        return isFinished;
    }
    /**
     * set the picked up state
     * @param isFinished
     */
    public void setPickedup(boolean isFinished)
    {
        this.isFinished = isFinished;
    }

}