public class Position {

    /**
     * position on rows
     */
    int rowId;
    /**
     * position on columns
     */
    int columnId;

    /**
     * Constructor
     * @param rowId
     * @param columnId
     */
    public Position(int rowId, int columnId)
    {
        this.rowId = rowId;
        this.columnId = columnId;
    }

    /**
     * getter for column
     * @return column id
     */
    public int getColumnId()
    {
        return columnId;
    }

    /**
     * setter for column
     * @param columnId
     */
    public void setColumnId(int columnId)
    {
        this.columnId = columnId;
    }
    /**
     * getter for row
     * @return row id
     */
    public int getRowId()
    {
        return rowId;
    }
    /**
     * setter for row
     * @param rowId
     */
    public void setRowId(int rowId)
    {
        this.rowId = rowId;
    }


}