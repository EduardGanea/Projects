import java.util.Random;

public class RandomNum {

    /**
     * generate a random number
     * @param lowerBound min value
     * @param upperBound max value
     * @return random value
     */
    int randomNumber(int lowerBound, int upperBound)
    {
        Random rand = new Random();
        int number = rand.nextInt(upperBound - lowerBound + 1) + lowerBound;

        return number;
    }
}
