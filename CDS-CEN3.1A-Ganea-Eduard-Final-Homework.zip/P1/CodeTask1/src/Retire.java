import java.util.Random;
import java.util.concurrent.Semaphore;

public class Retire extends Thread {
    Demon demon;            // a class used for the retirement of demons
    public Semaphore retire = new Semaphore(0);     // semaphore a demon acquires when it is the right time to do it
    Retire(Demon demon){      // the constructor for the retirement method
        this.demon = demon;
    }
    public void run(){
        Random rand = new Random();
        int time = rand.nextInt(100);   // we wait a bit of time before retirement
        try{
            sleep(time);
        } catch (InterruptedException ex){}
        if(retire.tryAcquire()){    // if the demon is ready as he acquired the semaphore
            demon.interrupt();      // we use the interrupt thread method as it is a safe method for thread termination
            demon = null;           // and the demon becomes a null instance
        }

    }
}