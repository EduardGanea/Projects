import java.util.ArrayList;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.ReentrantLock;

public class Coven extends Thread{

    /**
     * index of the coven
     */
    int CovenId;
    /**
     * the grid
     */
    CovenGrid grid;
    /**
     *  number of demons
     */
    int numberOfDemons;
    /**
     * list of the working demons
     */
    ArrayList<Demon> workingDemons;
    /**
     * coven lock
     */
    ReentrantLock CovenLock;
    /**
     * channel between Coven and Witch
     */
    LockBasedQueue<Ingredient> CovenWitch;
    /**
     * semaphore for the Witch and Coven
     */
    Semaphore WitchSem = new Semaphore(1);
    /**
     * barrier for Demons
     */
    CyclicBarrier DemonsBarrier;
    /**
     * constructor
     * @param CovenId
     * @param grid
     * @param numberOfDemons
     * @param workingDemons
     * @param CovenLock
     * @param CovenWitch
     * @param WitchSem
     */
    public Coven(int CovenId, CovenGrid grid, int numberOfDemons, ArrayList<Demon> workingDemons,
                 ReentrantLock CovenLock, LockBasedQueue<Ingredient> CovenWitch, Semaphore WitchSem)
    {
        this.CovenId = CovenId;
        this.grid = grid;
        this.numberOfDemons = numberOfDemons;
        this.workingDemons = workingDemons;
        this.CovenLock = CovenLock;
        this.CovenWitch = CovenWitch;
        this.WitchSem = WitchSem;
        this.DemonsBarrier = new CyclicBarrier(grid.getGridSize());
    }

    /**
     * the method that simulates the task of the coven
     * from the problem statement
     * it creates and starts the demons if the position for creation is valid, and every second
     * it questions the demons where they are because of the semaphore
     * the witch has to wait for the coven to finish.
     */
    public void run()
    {
        RandomNum rnd = new RandomNum();
        for(int i = 1; i <= numberOfDemons; i ++)
        {
            Position DemonPoz = new Position(rnd.randomNumber(101, 500), rnd.randomNumber(101, 500));
            int times =0;
            int maxtimes = rnd.randomNumber(20,30);
            while(true && times < maxtimes)
            {
                if(grid.isValidPosition(DemonPoz) == true)
                {
                    try{
                        Thread.sleep(rnd.randomNumber(501,1000));
                    } catch (InterruptedException e){
                        e.printStackTrace();
                    }
                    Demon someDemon = new Demon(i, 10, 0,DemonPoz, this, DemonsBarrier);
                    someDemon.start();
                    workingDemons.add(someDemon);
                    someDemon.notifyCoven();
                    break;
                }
                else
                {
                    DemonPoz.setRowId(rnd.randomNumber(101, 500));
                    DemonPoz.setColumnId(rnd.randomNumber(101, 500));
                }
                times++;
            }
            if(times == maxtimes){
                Retire ret = new Retire(workingDemons.get(i));
                ret.start();
            }
        }
        int loops = 0;
        while(true)
        {
            loops ++;
            try {
                WitchSem.acquire();
            } catch (InterruptedException e1) {
                e1.printStackTrace();
            }
            for(int i = 0; i < workingDemons.size(); i ++)
            {
                Position DemonPoz = workingDemons.get(i).getPoz();
                System.out.println(DemonPoz.getRowId() + ", " + DemonPoz.getColumnId() + " " + CovenId);
            }
            WitchSem.release();
            if(loops == 2)
            {
                break;
            }
        }
        System.out.println("Termina Coven-ul " + CovenId);
    }

    /**
     * getter for Coven id
     * @return Coven id
     */
    public int getCovenId()
    {
        return CovenId;
    }
    /**
     * setter for Coven id
     * @param CovenId
     */
    public void setCovenId(int CovenId)
    {
        this.CovenId = CovenId;
    }

    /**
     * getter for grid
     * @return
     */
    public CovenGrid getGrid()
    {
        return grid;
    }

    /**
     * setter for grid
     * @param grid
     */
    public void setGrid(CovenGrid grid)
    {
        this.grid = grid;
    }

    /**
     * getter for number of demons
     * @return number of demons
     */
    public int getNumberOfDemons()
    {
        return numberOfDemons;
    }
    /**
     * setter for number of demons
     * @param numberOfDemons
     */
    public void setNumberOfDemons(int numberOfDemons)
    {
        this.numberOfDemons = numberOfDemons;
    }

    /**
     * getter for the list of working demons
     * @return list of working demons
     */
    public ArrayList<Demon> getWorkingDemons()
    {
        return workingDemons;
    }

    /**
     * setter for the list of working demons
     * @param workingDemons
     */
    public void setWorkingDemons(ArrayList<Demon> workingDemons)
    {
        this.workingDemons = workingDemons;
    }

    /**
     * getter for coven lock
     * @return return coven lock
     */
    public ReentrantLock getCovenLock()
    {
        return CovenLock;
    }
    /**
     * setter for coven lock
     * @param CovenLock
     */
    public void setCovenLock(ReentrantLock CovenLock)
    {
        this.CovenLock = CovenLock;
    }
    /**
     * getter for channel between coven and witch
     * @return channel between coven and witch
     */
    public LockBasedQueue<Ingredient> getCovenWitch()
    {
        return CovenWitch;
    }
    /**
     * setter for channel between Coven and Witch
     * @param CovenWitch
     */
    public void setCovenWitch(LockBasedQueue<Ingredient> CovenWitch)
    {
        this.CovenWitch = CovenWitch;
    }


}
