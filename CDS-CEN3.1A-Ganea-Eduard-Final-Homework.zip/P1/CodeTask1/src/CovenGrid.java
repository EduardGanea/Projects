public class CovenGrid {

    /**
     * id of the grid
     */
    int gridId;
    /**
     * size of the grid
     */
    int gridSize;
    /**
     * the grid, where the demons are
     * true means invalid position/occupied
     * false means valid position/not occupied
     */
    boolean grid[][] = new boolean[gridSize][gridSize];

    /**
     * constructor
     * @param gridId
     * @param gridSize
     * @param grid
     */
    public CovenGrid(int gridId, int gridSize, boolean grid[][])
    {
        this.gridId = gridId;
        this.gridSize = gridSize;
        this.grid = grid;
        borderMatrix(this.gridSize,this.grid);
    }

    /**
     * border the matrix to make sure that demons to not go outside it
     * @param gridSize
     * @param grid
     */
    public void borderMatrix(int gridSize, boolean grid[][])
    {
        for(int i = 0; i < gridSize; i ++)
        {
            grid[i][0] = true;
            grid[i][gridSize - 1] = true;
            grid[0][i] = true;
            grid[gridSize - 1][i] = true;
        }
    }

    /**
     * check if a given position is valid
     * @param poz
     * @return
     */
    public boolean isValidPosition(Position poz)
    {
        return this.grid[poz.getRowId()][poz.getColumnId()] == false;

    }
    /**
     * getter for grid
     * @return grid
     */
    public boolean[][] getGrid() {
        return grid;
    }
    /**
     * setter for grid
     * @param grid
     */
    public void setGrid(boolean[][] grid) {
        this.grid = grid;
    }

    /**
     * getter for grid index
     * @return grid index
     */
    public int getGridId() {
        return gridId;
    }

    /**
     * setter for grid index
     * @param gridId
     */
    public void setGridId(int gridId) {
        this.gridId = gridId;
    }
    /**
     * getter for grid size
     * @return grid size
     */
    public int getGridSize() {
        return gridSize;
    }
    /**
     * setter for grid size
     * @param gridSize
     */
    public void setGridSize(int gridSize) {
        this.gridSize = gridSize;
    }

}
