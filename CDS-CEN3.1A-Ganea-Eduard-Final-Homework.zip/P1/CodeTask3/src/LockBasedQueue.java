import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class LockBasedQueue<T>
{
    /**
     * This variable represents the
     * head of the queue
     */
    volatile int head;
    /**
     * This variable represents the
     * end of the queue
     */
    volatile int tail;

    /**
     * the items that are stored
     */
    T[] itemsArray;
    /**
     * the reentrant lock
     */
    Lock lock;
    /**
     * conditions that take care of
     * the corner cases (empty or full)
     */
    Condition condEmpty;
    Condition condFull;

    /**
     * constructor
     * @param arraySize size of the queue
     */
    public LockBasedQueue(int arraySize)
    {
        head = 0;
        tail = 0;
        lock = new ReentrantLock();
        condEmpty = lock.newCondition();
        condFull = lock.newCondition();
        itemsArray = (T[]) new Object[arraySize];
    }


    /**
     * this method returns and removes
     * the first element of the queue
     * First it tries to acquire the lock
     * then checks if the queue is empty
     * then takes the element
     * @return the first element of the queue
     */
    public T dequeue()
    {
        lock.lock();
        try
        {
            while(tail == head)
            {
                try {
                    condEmpty.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            T x = itemsArray[head % itemsArray.length];
            head++;
            condFull.signalAll();
            return x;
        } finally {
            lock.unlock();
        }
    }

    /**
     * this method adds an element
     * at the end of the queue
     * First it tries to acquire the lock
     * then it checks if the queue is full
     * and then, adds x to the queue
     * @param x value to add
     */
    public void enqueue(T x)
    {
        lock.lock();
        try {
            while (tail - head == itemsArray.length)
            {
                try {
                    condFull.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            itemsArray[tail % itemsArray.length] = x;
            tail++;
        } finally {
            condEmpty.signalAll();
            lock.unlock();
        }
    }
}
