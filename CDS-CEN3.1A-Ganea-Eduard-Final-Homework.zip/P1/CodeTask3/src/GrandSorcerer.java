import java.util.ArrayList;

public class GrandSorcerer extends Thread{

    /**
     * channel between Witch and Grand Sorcerer
     */
    LockBasedQueue<Ingredient> WitchGrandSorcerer;
    /**
     * the bag with potions
     */
    ArrayList<Ingredient> PotionsToSaveTheWorld;
    /**
     * number of potions, or the max size of the bag
     */
    int numberPotions;


    /**
     * Constructor
     * @param WitchGrandSorcerer
     * @param PotionsToSaveTheWorld
     * @param numberPotions
     */
    public GrandSorcerer(LockBasedQueue<Ingredient> WitchGrandSorcerer, ArrayList<Ingredient> PotionsToSaveTheWorld, int numberPotions)
    {
        this.WitchGrandSorcerer = WitchGrandSorcerer;
        this.PotionsToSaveTheWorld = PotionsToSaveTheWorld;
        this.numberPotions = numberPotions;
    }

    /**
     * method that gets the list of potions from witch
     * and checks if there are enough potions in order to save the world
     */
    public void run()
    {
        boolean runnable = true;
        while(runnable)
        {

            Ingredient Potion = WitchGrandSorcerer.dequeue();
            PotionsToSaveTheWorld.add(Potion);


            if(PotionsToSaveTheWorld.size() == numberPotions)
            {
                runnable = false;
            }
        }
    }

    /**
     * getter for channel between Witch and Grand Sorcerer
     * @return the channel
     */
    public LockBasedQueue<Ingredient> getWitchGrandSorcerer()
    {
        return WitchGrandSorcerer;
    }

    /**
     * setter for the channel between Witch and Grand Sorcerer
     * @param WitchGrandSorcerer
     */
    public void setWitchGrandSorcerer(LockBasedQueue<Ingredient> WitchGrandSorcerer)
    {
        this.WitchGrandSorcerer = WitchGrandSorcerer;
    }
    /**
     * getter for Grand Sorcerer's bag
     * @return Grand Sorcerer's bag
     */
    public ArrayList<Ingredient> getPotionsToSaveTheWorld()
    {
        return PotionsToSaveTheWorld;
    }

    /**
     * setter for Grand Sorcerer's bag
     * @param PotionsToSaveTheWorld
     */
    public void setPotionsToSaveTheWorld(ArrayList<Ingredient> PotionsToSaveTheWorld)
    {
        this.PotionsToSaveTheWorld = PotionsToSaveTheWorld;
    }

    /**
     * getter for the number of potions
     * @return number of potions
     */
    public int getNumberPotions()
    {
        return numberPotions;
    }
    /**
     * setter for the number of potions
     * @param numberPotions
     */
    public void setNumberPotions(int numberPotions)
    {
        this.numberPotions = numberPotions;
    }


}
