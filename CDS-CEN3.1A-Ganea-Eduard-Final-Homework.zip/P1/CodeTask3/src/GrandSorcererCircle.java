import java.util.ArrayList;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.ReentrantLock;

public class GrandSorcererCircle extends Thread{

    /**
     * Method that starts the problem.
     */
    public void run()
    {
        RandomNum rand = new RandomNum();
        /**
         * list with the covens
         */
        ArrayList<Coven>  CovenList = new ArrayList<Coven>();
        /**
         * list with the Witches
         */
        ArrayList<Witch> WitchList = new ArrayList<Witch>();
        /**
         * list with the Undeads
         */
        ArrayList<Undead> UndeadList = new ArrayList<Undead>();

        int gridSize = 502;

        int numberOfDemons = rand.randomNumber(0,gridSize/2);

        /**
         * list with the working demons
         */
        ArrayList<Demon> workingDemons;
        /**
         * locks for the covens
         */
        ReentrantLock CovenLock;
        /**
         * channel between Coven and the Witch
         */
        LockBasedQueue<Ingredient> CovenWitch;
        /**
         * channel between Witch and Grand Sorcerer
         */
        LockBasedQueue<Ingredient> WitchGrandSorcerer = new LockBasedQueue<Ingredient>(1000);
        /**
         * channel between Coven and Undead
         */
        LockBasedQueue<Ingredient> CovenUndead = new LockBasedQueue<Ingredient>(100);

        /**
         * Grand Sorcerer's bag with potions
         */
        ArrayList<Ingredient> PotionsToSaveTheWorld = new ArrayList<Ingredient>(70);

        /**
         * semaphore for the witch and the coven
         */
        Semaphore WitchSem;
        /**
         * semaphore for the undead and the coven
         */
        Semaphore UndeadSem;
        /**
         * number of potions to save the world
         */
        int numberPotions = rand.randomNumber(20,30);
        /**
         * the grid
         */
        CovenGrid grid;
        /**
         * number of covens
         */
        int covenNumber = rand.randomNumber(3,20);

        for(int i = 1; i <= covenNumber; i ++)      // the creation of covens, witches and undeads
        {
            boolean grd[][] = new boolean[gridSize][gridSize];
            grid = new CovenGrid(i, gridSize, grd);
            CovenLock = new ReentrantLock();
            workingDemons = new ArrayList<Demon>();
            CovenWitch = new LockBasedQueue<Ingredient>(60);
            WitchSem = new Semaphore(1);
            UndeadSem = new Semaphore(1);
            Coven currentCoven = new Coven(i, grid, numberOfDemons, workingDemons,
                    CovenLock, CovenWitch, WitchSem);
            CovenList.add(currentCoven);

            for(int j = 1; j <= 10; j ++)
            {
                Witch currentWitch = new Witch(j, currentCoven, CovenWitch,
                        WitchGrandSorcerer, WitchSem);
                WitchList.add(currentWitch);
            }
            for(int k = 1; k <= rand.randomNumber(21,50); k++){
                Undead currentUndead = new Undead(k,currentCoven, CovenUndead, UndeadSem);
                UndeadList.add(currentUndead);
            }
        }
        (new GrandSorcerer(WitchGrandSorcerer, PotionsToSaveTheWorld, numberPotions)).start();  // grand sorcerer starting his battle

        for(int i = 0; i < CovenList.size(); i ++)  // the covens, witches and undeads starting their work
        {
            CovenList.get(i).start();

            for(int j = i * 10; j < i * 10 + 10; j ++)
            {
                WitchList.get(j).start();
            }
            for(int j = i *10; j < i *10 +10; j++){
                UndeadList.get(j).start();
            }
        }
    }
}