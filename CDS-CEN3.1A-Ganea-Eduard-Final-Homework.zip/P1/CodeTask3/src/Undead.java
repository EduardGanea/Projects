import java.util.concurrent.Semaphore;


public class Undead extends Thread{
    /**
     * the id of the undead
     */
    int UndeadId;
    /**
     * The coven that the undead attacks
     */
    Coven cvn;
    /**
     * Channel between coven and undead
     */
    LockBasedQueue<Ingredient> CovenUndead;
    /**
     * Semaphore for Undead and coven
     */
    Semaphore UndeadSem;

    /**
     * Constructor
     * @param UndeadId
     * @param cvn
     * @param CovenUndead
     * @param UndeadSem
     */
    public Undead(int UndeadId, Coven cvn, LockBasedQueue<Ingredient> CovenUndead, Semaphore UndeadSem){
        this.UndeadId = UndeadId;
        this.cvn = cvn;
        this.CovenUndead = CovenUndead;
        this.UndeadSem = UndeadSem;
    }
    /**
     * Method that simulates the attack of the Undead
     * from the problem statement
     */
    public void run()
    {
        RandomNum rand = new RandomNum();
        UndeadSem.tryAcquire();
        Ingredient PotionDestroyed = CovenUndead.dequeue();
        UndeadSem.release();
        System.out.println("Am distrus o potiune");
        DestroyPotion(PotionDestroyed);
        int time = rand.randomNumber(501, 1000);
        try{
            Thread.sleep(time);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
    }
    /**
     * Method that destroys the potions.
     * @param PotionDestroyed
     */
    public void DestroyPotion(Ingredient PotionDestroyed)
    {
        PotionDestroyed.setPickedup(false);

    }

    /**
     * getter for the undead id
     * @return undead id
     */
    public int getUndeadIdId()
    {
        return UndeadId;
    }
    /**
     * setter for the undead id
     * @param UndeadId
     */
    public void setUndeadId(int UndeadId)
    {
        this.UndeadId = UndeadId;
    }
    /**
     * getter for coven
     * @return the coven
     */
    public Coven getCvn()
    {
        return cvn;
    }

    /**
     * setter for coven
     * @param cvn
     */
    public void setCvn(Coven cvn)
    {
        this.cvn = cvn;
    }
    /**
     * getter for the channel between coven and undead
     * @return channel between coven and undead
     */
    public LockBasedQueue<Ingredient> getCovenUndead()
    {
        return CovenUndead;
    }
    /**
     * setter for the channel between coven and undead
     * @param CovenUndead
     */
    public void setCovenUndead(LockBasedQueue<Ingredient> CovenUndead)
    {
        this.CovenUndead = CovenUndead;
    }


}
