import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MatrixProblem {

    //Creating the matrix
    static int[][] mat = new int[1024][1024];
    static int[][] mat2 = new int[1024][1024];
    static int[][] result = new int[1024][1024];


    public static void main(String[] args) {

        //Creating the object of random class
        Random rand = new Random();

        //Filling first matrix with random values
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                mat[i][j] = rand.nextInt(10);
            }
        }

        //Filling second matrix with random values
        for (int i = 0; i < mat2.length; i++) {
            for (int j = 0; j < mat2[i].length; j++) {
                mat2[i][j] = rand.nextInt(10);
            }
        }

        try {
            //Object of multiply Class
            Multiply multiply = new Multiply(1024, 1024);
            int numberOfThreadsInPool = 1024;
            int numberOfThreads = 1024;
            //Threads
            ExecutorService executor = Executors.newFixedThreadPool(numberOfThreadsInPool);
            // their creation and their start
            for (int i = 0; i < numberOfThreads; i++) {
                Runnable worker = new Thread(new MatrixMultiplier(multiply));
                executor.execute(worker);
            }
            executor.shutdown();
            while (!executor.isTerminated()) {
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        //Printing the result
        System.out.println("\n\nResult:");
        for (int i = 0; i < result.length; i++) {
            for (int j = 0; j < result[i].length; j++) {
                System.out.print(result[i][j] + " ");
            }
            System.out.println();
        }
    }

}

class Multiply extends MatrixProblem {

    private int i;  // row
    private int j;  // column
    private int count; // used for putting the elements in the result matrix in order and also to
                        // make the multiplication operation correct and also in a divde-et-impera way

    public Multiply(int i, int j){  // cosntructor
        this.i=i;
        this.j=j;
        count=0;
    }

    //Matrix Multiplication Function
    public synchronized void multiplyMatrix(){

        int sum;
        int a;
        for(a=0;a<i;a++){
            sum=0;
            for(int b=0;b<j;b++){
                sum=sum+mat[count][b]*mat2[b][a];  // we do the operation for the calculation of the element
            }
            result[count][a]=sum;      // we put it in the result matrix
        }

        if(count>=i)   // we stop if count is higher than i because we go out of the matrix's bounds
            return;
        count++;   // we get to the next position
    }
}

class MatrixMultiplier implements Runnable {

    private final Multiply mul; // instance of multiply so we can use its operation multiplymatrix in the start method

    public MatrixMultiplier(Multiply mul){
        this.mul=mul;
    }   // cosntructor

    @Override
    public void run() {
        mul.multiplyMatrix();
    }   // start method for a thread doing the multiplication of matrices
}