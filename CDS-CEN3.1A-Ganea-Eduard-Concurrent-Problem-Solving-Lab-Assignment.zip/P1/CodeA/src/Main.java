import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

public class Main{
    public static void main(String args[]) {
        List<String> str = new LinkedList<>();
        List<String> str2 = new LinkedList<>();
        List<String> str3 = new LinkedList<>();
        List<String> str4 = new LinkedList<>();
        ReentrantLock lock = new ReentrantLock();
        ReentrantLock lock2 = new ReentrantLock();
        ReentrantLock lock3 = new ReentrantLock();
        ReentrantLock lock4 = new ReentrantLock();

        Thread t1 = new Thread(new Producer(str, lock));        // creating the producer instance
        Thread t2 = new Thread(new Consumer(str, lock));        // creating the consumer instance
        Thread t3 = new Thread(new Producer(str2, lock2));
        Thread t6 = new Thread(new Consumer(str2, lock2));
        Thread t4 = new Thread(new Producer(str3, lock3));
        Thread t7 = new Thread(new Consumer(str3, lock3));
        Thread t5 = new Thread(new Producer(str4, lock4));
        Thread t8 = new Thread(new Consumer(str4, lock4));
        t1.start();     // threads starting
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        t6.start();
        t7.start();
        t8.start();
    }
}
