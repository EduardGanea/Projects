import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class Consumer extends Thread {
    private List<String> data;      // list used for retaining the number of data written
    private ReentrantLock lock;     // the lock

    Consumer(List<String> data,ReentrantLock lock)      // constructor
    {
        this.data = data;
        this.lock = lock;
    }

    public void run() {
        int i = 0;          // used as the number of iterations
        while (i < 10)
        {
            try {
                lock.lock();
                if ( data.size() > 0)      // we want to have one value written at a time and that value to be here for the printing
                {
                    System.out.println("reading:: "+data.get(data.size()-1));
                    data.remove(data.size()-1);
                }
            }finally {
                lock.unlock();
            }
            try
            {
                TimeUnit.SECONDS.sleep(1);      // used so the program won`t block as a timing between incrementations
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            i++;
        }
    }
}

