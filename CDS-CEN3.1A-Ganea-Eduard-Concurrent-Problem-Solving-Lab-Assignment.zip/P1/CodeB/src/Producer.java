import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class Producer extends Thread {
    private List<String> data;      // list used for retaining the number of data written
    private ReentrantLock lock;     // the lock

    Producer(List<String> data,ReentrantLock lock)  // constructor
    {
        this.data = data;
        this.lock = lock;
    }

    public void run() {
        int counter = 0;        // used as the number incremented
        int i = 0;              // used as the number of iterations
        while (i < 10)
        {
            try {
                lock.lock();
                if ( data.size() < 5)       // we can`t print more than 5 values at a time or the program will block, printing only the 5 values
                {
                    counter++;
                    data.add("writing:: " + counter);
                }
            }finally {
                lock.unlock();
            }

            try {
                TimeUnit.SECONDS.sleep(1);      // used so the program won`t block as a timing between incrementations
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            i++;
        }
    }
}
